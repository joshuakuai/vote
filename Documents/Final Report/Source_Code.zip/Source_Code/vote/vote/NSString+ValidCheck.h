//
//  NSString+ValidCheck.h
//  vote
//
//  Created by kuaijianghua on 11/3/13.
//  Copyright (c) 2013 rampageworks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (ValidCheck)

- (BOOL)isValidEmail;

@end
