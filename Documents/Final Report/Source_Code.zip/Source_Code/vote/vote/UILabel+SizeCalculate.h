//
//  UILabel+SizeCalculate.h
//  vote
//
//  Created by kuaijianghua on 11/30/13.
//  Copyright (c) 2013 rampageworks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (SizeCalculate)

- (CGSize)perfectLabelSizeWithMaxSize:(CGSize)maxSize;

@end
